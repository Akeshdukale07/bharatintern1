console.log('This is drag and drop utility');

const imgBox = document.querySelector('.imgBox');
const whiteBoxes = document.getElementsByClassName('whiteBox');
const textDropZone = document.getElementById('textDropZone');
const videoDropZone = document.getElementById('videoDropZone');

imgBox.addEventListener('dragstart', (e) => {
    console.log('DragStart has been triggered');
    e.target.className += ' hold';
    setTimeout(() => {
        e.target.className = 'hide';
    }, 0);
});

imgBox.addEventListener('dragend', (e) => {
    console.log('DragEnd has been triggered');
    e.target.className = 'imgBox';
});

textDropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    console.log('DragOver for text has been triggered');
});

textDropZone.addEventListener('drop', (e) => {
    console.log('Drop for text has been triggered');
    const droppedText = e.dataTransfer.getData('text/plain');
    const newTextElement = document.createElement('div');
    newTextElement.classList.add('textElement');
    newTextElement.textContent = droppedText;
    textDropZone.appendChild(newTextElement);
});

videoDropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    console.log('DragOver for video has been triggered');
});

videoDropZone.addEventListener('drop', (e) => {
    console.log('Drop for video has been triggered');
    const droppedVideoUrl = e.dataTransfer.getData('text/plain');
    const newVideoElement = document.createElement('video');
    newVideoElement.classList.add('videoElement');
    newVideoElement.src = droppedVideoUrl;
    newVideoElement.controls = true;
    videoDropZone.appendChild(newVideoElement);
});
